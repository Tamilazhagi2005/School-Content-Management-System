%{
  name: "Elixir Club Evening 4",
  link: "http://www.elixirkyiv.club",
  date:  ~D[2020-11-19]
}
---

Elixir Club Evening 4
