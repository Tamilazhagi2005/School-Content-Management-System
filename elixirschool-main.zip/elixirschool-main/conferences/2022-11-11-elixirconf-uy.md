%{
  name: "ElixirConf UY 2022",
  series: "ElixirConf UY",
  link: "https://elixirconf.uy/",
  date:  ~D[2022-11-11],
  location: "Montevideo, Uruguay",
  country: "Uruguay"
}
---

ElixirConf UY 2022
