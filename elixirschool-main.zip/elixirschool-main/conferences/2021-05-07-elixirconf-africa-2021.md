%{
  name: "ElixirConf Africa 2021",
  series: "ElixirConf Africa",
  link: "https://elixirconf.africa/",
  date:  ~D[2021-05-07]
}
---

ElixirConf Africa 2021
