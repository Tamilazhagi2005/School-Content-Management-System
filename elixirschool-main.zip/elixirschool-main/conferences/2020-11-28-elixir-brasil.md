%{
  name: "Elixir Brasil 2020",
  series: "Elixir Brasil",
  link: "https://2020.elixirbrasil.com",
  date:  ~D[2020-11-28],
  location: "São Paulo, Brazil",
  country: "Brazil"
}
---

Elixir Brasil 2020
