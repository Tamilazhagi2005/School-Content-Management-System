%{
  name: "ElixirConf EU 2020",
  series: "ElixirConf EU",
  link: "https://www.elixirconf.eu/",
  date:  ~D[2020-10-07]
}
---

ElixirConf EU 2020
