%{
  name: "ElixirConf NA 2021",
  series: "ElixirConf NA",
  link: "https://2021.elixirconf.com/",
  date:  ~D[2021-10-12],
  location: "Austin, TX",
  country: "United States"
}
---

Elixir Conf 2021
