%{
  name: "Alchemy Conf 2021",
  link: "https://alchemyconf.com",
  date:  ~D[2021-05-28]
}
---

Alchemy Conf 2021
