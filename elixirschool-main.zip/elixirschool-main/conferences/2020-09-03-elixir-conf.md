%{
  name: "ElixirConf NA 2020",
  series: "ElixirConf NA",
  link: "https://2020.elixirconf.com/",
  date:  ~D[2020-09-03]
}
---

ElixirConf NA 2020
