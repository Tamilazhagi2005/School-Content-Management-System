%{
  name: "Elixir Wizards |> Conference",
  link: "https://hopin.com/events/elixir-wizards-conference",
  date:  ~D[2021-06-16]
}
---

Elixir Wizards |> Conference
