%{
  name: "ElixirConf Africa 2022",
  series: "ElixirConf Africa",
  link: "https://elixirconf.africa/",
  date:  ~D[2022-10-06]
}
---

ElixirConf Africa 2022
